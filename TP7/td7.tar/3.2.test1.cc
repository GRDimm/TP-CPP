#include "3.2.h"

int main() {
  Array a(5);
  Array b = a;
}
