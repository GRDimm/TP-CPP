#include "1.1.h"

class Yo : public Sequence {
  void Next() {}
};

int main() {
  Yo yo;
}
