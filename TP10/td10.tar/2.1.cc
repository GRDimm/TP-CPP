#include <iostream>
using namespace std;

#include "2.1.h"

// Don't touch this function.
string StraightSquare::Name() {
  return "Square";
}

// TODO(you): implement the rest!
