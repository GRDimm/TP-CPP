#include "1.1.h"

class Yo : public Sequence {
  double Value() { return 0.0; }
};

int main() {
  Yo yo;
}
