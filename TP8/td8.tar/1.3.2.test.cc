#include "main_utils.h"
#include "1.3.h"

int main() {
  Matrix a(1, 1);
  Matrix b = a;
  cout << "PASSED" << endl;
}
