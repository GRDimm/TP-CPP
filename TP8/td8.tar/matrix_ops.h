
void PrintMatrix(const Matrix& m);
Matrix MatrixProd(const Matrix& a, const Matrix& b);
Matrix MatrixPower(const Matrix& m, int p);
