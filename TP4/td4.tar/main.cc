#include "io.h"

int main(){
    Class* Cl = EnterClass();
    PrintClass(*Cl);
    return 0;
}