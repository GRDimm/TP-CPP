#include <iostream>

using namespace std;

int LaSolution(int x){
    return x + 42;
}