#include <iostream>
using namespace std;

#include "2.2.cc"

int main() {
  cout << "Entrez un entier n: ";
  int n;
  cin >> n;
  cout << FactorielleMod2(n) << endl;
}