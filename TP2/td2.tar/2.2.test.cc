#include <iostream>
using namespace std;
#include "2.2.cc"
int main() { std::cout << FactorielleMod2(45362873) << "\n"; }