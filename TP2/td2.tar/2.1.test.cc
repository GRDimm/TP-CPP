#include <iostream>
using namespace std;
#include "2.1.cc"
int main() { std::cout << FactorielleMod(873) << "\n"; }