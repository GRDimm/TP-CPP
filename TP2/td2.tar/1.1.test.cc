#include <iostream>
using namespace std;
int LaSolution(int x);
int main() {
  cout << LaSolution(5172) << endl;
}