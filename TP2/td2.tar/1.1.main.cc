#include <iostream>
using namespace std;

#include "1.1.cc"

int main() {
  cout << LaSolution(3) << endl;
  cout << LaSolution(-1) << endl;
}