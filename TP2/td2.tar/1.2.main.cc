#include <iostream>
using namespace std;

int LaSolution(int n);

int main() {
  cout << LaSolution(3) << endl;
  cout << LaSolution(-1) << endl;
}